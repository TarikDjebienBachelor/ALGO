#ifndef UN_GRAPHE_H
#define UN_GRAPHE_H 1

#include "def_graphe.h"

#define n 9

extern int B [n][n];
extern struct vertex S [n];

#endif /* !UN_GRAPHE_H */
